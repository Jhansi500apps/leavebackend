from fastapi import FastAPI, HTTPException, Depends, status, APIRouter
from sqlalchemy.orm import Session
from pydantic import BaseModel
from datetime import date
from typing import List
from routers.sql import Employee, engine
from sqlalchemy.orm import sessionmaker


# app = FastAPI()
router = APIRouter()
# from fastapi.middleware.cors import CORSMiddleware


# Define a list of allowed origins for CORS
# You can use ["*"] to allow all origins
# origins = [
#     "http://localhost:3000",  # Assuming your Vue.js app runs on localhost:3000
#     "http://127.0.0.1:3000",
#     # Add other origins as needed
# ]

# # app.add_middleware(
#     CORSMiddleware,
#     allow_origins=origins,  # List of allowed origins
#     allow_credentials=True,
#     allow_methods=["*"],  # Allows all methods
#     allow_headers=["*"],  # Allows all headers
# )
# Dependency
def get_db():
    db = sessionmaker(autocommit=False, autoflush=False, bind=engine)()
    try:
        yield db
    finally:
        db.close()

# Pydantic models for Employee
class EmployeeCreate(BaseModel):
    first_name: str
    last_name: str
    email: str
    department: str
    position: str
    join_date: date
    status: str = "active"

class EmployeeUpdate(BaseModel):
    first_name: str
    last_name: str
    email: str
    department: str
    position: str
    join_date: date
    status: str

class EmployeeOut(BaseModel):
    employee_id: int
    first_name: str
    last_name: str
    email: str
    department: str
    position: str
    join_date: date
    status: str

    class Config:
        from_attributes = True 
# CRUD operations
@router.post("/employees/", response_model=EmployeeOut, status_code=status.HTTP_201_CREATED)
def create_employee(employee: EmployeeCreate, db: Session = Depends(get_db)):
    db_employee = Employee(**employee.dict())
    db.add(db_employee)
    db.commit()
    db.refresh(db_employee)
    return db_employee

@router.get("/employees/", response_model=List[EmployeeOut])
def read_employees(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    employees = db.query(Employee).offset(skip).limit(limit).all()
    return employees

@router.get("/employees/{employee_id}", response_model=EmployeeOut)
def read_employee(employee_id: int, db: Session = Depends(get_db)):
    employee = db.query(Employee).filter(Employee.employee_id == employee_id).first()
    if employee is None:
        raise HTTPException(status_code=404, detail="Employee not found")
    return employee

@router.put("/employees/{employee_id}", response_model=EmployeeOut)
def update_employee(employee_id: int, employee: EmployeeUpdate, db: Session = Depends(get_db)):
    db_employee = db.query(Employee).filter(Employee.employee_id == employee_id).first()
    if db_employee is None:
        raise HTTPException(status_code=404, detail="Employee not found")
    for var, value in vars(employee).items():
        setattr(db_employee, var, value) if value else None
    db.commit()
    db.refresh(db_employee)
    return db_employee

@router.delete("/employees/{employee_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_employee(employee_id: int, db: Session = Depends(get_db)):
    db_employee = db.query(Employee).filter(Employee.employee_id == employee_id).first()
    if db_employee is None:
        raise HTTPException(status_code=404, detail="Employee not found")
    db.delete(db_employee)
    db.commit()
    return {"ok": True}