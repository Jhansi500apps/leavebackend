from fastapi import FastAPI, HTTPException, Depends, status, APIRouter
from sqlalchemy.orm import Session
from pydantic import BaseModel
from datetime import date
from typing import List
from datetime import date, datetime
from routers.sql import LeaveRequest,engine
from sqlalchemy.orm import sessionmaker
 # Assuming LeaveType is also in the sql module\
router = APIRouter()
# app = FastAPI()
# from fastapi.middleware.cors import CORSMiddleware


# # Define a list of allowed origins for CORS
# # You can use ["*"] to allow all origins
# origins = [
#     "http://localhost:3000",  # Assuming your Vue.js app runs on localhost:3000
#     "http://127.0.0.1:3000",
#     # Add other origins as needed
# ]

# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=origins,  # List of allowed origins
#     allow_credentials=True,
#     allow_methods=["*"],  # Allows all methods
#     allow_headers=["*"],  # Allows all headers
# )
# Dependency
def get_db():
    db = sessionmaker(autocommit=False, autoflush=False, bind=engine)()
    try:
        yield db
    finally:
        db.close()


class LeaveRequestCreate(BaseModel):
    employee_id: int
    leave_type_id: int
    start_date: date
    end_date: date
    reason: str
    status: str = 'pending'

class LeaveRequestUpdate(BaseModel):
    start_date: date
    end_date: date
    reason: str
    status: str

class LeaveRequestOut(BaseModel):
    leave_request_id: int
    employee_id: int
    leave_type_id: int
    start_date: date
    end_date: date
    reason: str
    status: str
    request_date: datetime

    class Config:
        orm_mode = True

# Assuming get_db and other necessary imports are already defined

@router.post("/leave-requests/", response_model=LeaveRequestOut, status_code=status.HTTP_201_CREATED)
def create_leave_request(leave_request: LeaveRequestCreate, db: Session = Depends(get_db)):
    db_leave_request = LeaveRequest(**leave_request.dict())
    db.add(db_leave_request)
    db.commit()
    db.refresh(db_leave_request)
    return db_leave_request

@router.get("/leave-requests/", response_model=List[LeaveRequestOut])
def read_leave_requests(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    leave_requests = db.query(LeaveRequest).offset(skip).limit(limit).all()
    return leave_requests

@router.get("/leave-requests/{leave_request_id}", response_model=LeaveRequestOut)
def read_leave_request(leave_request_id: int, db: Session = Depends(get_db)):
    leave_request = db.query(LeaveRequest).filter(LeaveRequest.leave_request_id == leave_request_id).first()
    if leave_request is None:
        raise HTTPException(status_code=404, detail="LeaveRequest not found")
    return leave_request

@router.put("/leave-requests/{leave_request_id}", response_model=LeaveRequestOut)
def update_leave_request(leave_request_id: int, leave_request: LeaveRequestUpdate, db: Session = Depends(get_db)):
    db_leave_request = db.query(LeaveRequest).filter(LeaveRequest.leave_request_id == leave_request_id).first()
    if db_leave_request is None:
        raise HTTPException(status_code=404, detail="LeaveRequest not found")
    update_data = leave_request.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_leave_request, key, value)
    db.commit()
    db.refresh(db_leave_request)
    return db_leave_request

@router.delete("/leave-requests/{leave_request_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_leave_request(leave_request_id: int, db: Session = Depends(get_db)):
    db_leave_request = db.query(LeaveRequest).filter(LeaveRequest.leave_request_id == leave_request_id).first()
    if db_leave_request is None:
        raise HTTPException(status_code=404, detail="LeaveRequest not found")
    db.delete(db_leave_request)
    db.commit()
    return {"ok": True}
