from fastapi import FastAPI, HTTPException, Depends, status,APIRouter
from sqlalchemy.orm import Session
from pydantic import BaseModel
from datetime import date
from typing import List
from routers.sql import LeaveStatus, engine
from sqlalchemy.orm import sessionmaker
 # Assuming LeaveType is also in the sql module
# app= FastAPI()
router = APIRouter()
# from fastapi.middleware.cors import CORSMiddleware


# # Define a list of allowed origins for CORS
# # You can use ["*"] to allow all origins
# origins = [
#     "http://localhost:3000",  # Assuming your Vue.js app runs on localhost:3000
#     "http://127.0.0.1:3000",
#     # Add other origins as needed
# ]

# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=origins,  # List of allowed origins
#     allow_credentials=True,
#     allow_methods=["*"],  # Allows all methods
#     allow_headers=["*"],  # Allows all headers
# )
# Dependency
def get_db():
    db = sessionmaker(autocommit=False, autoflush=False, bind=engine)()
    try:
        yield db
    finally:
        db.close()


class LeaveStatusBase(BaseModel):
    status_name: str

class LeaveStatusCreate(LeaveStatusBase):
    pass

class LeaveStatusOut(LeaveStatusBase):
    status_id: int

    class Config:
        orm_mode = True


@router.post("/leave-status/", response_model=LeaveStatusOut, status_code=status.HTTP_201_CREATED)
def create_leave_status(leave_status: LeaveStatusCreate, db: Session = Depends(get_db)):
    db_leave_status = LeaveStatus(**leave_status.dict())
    db.add(db_leave_status)
    db.commit()
    db.refresh(db_leave_status)
    return db_leave_status

@router.get("/leave-status/", response_model=List[LeaveStatusOut])
def read_leave_statuses(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    leave_statuses = db.query(LeaveStatus).offset(skip).limit(limit).all()
    return leave_statuses

@router.get("/leave-status/{status_id}", response_model=LeaveStatusOut)
def read_leave_status(status_id: int, db: Session = Depends(get_db)):
    leave_status = db.query(LeaveStatus).filter(LeaveStatus.status_id == status_id).first()
    if leave_status is None:
        raise HTTPException(status_code=404, detail="LeaveStatus not found")
    return leave_status

@router.put("/leave-status/{status_id}", response_model=LeaveStatusOut)
def update_leave_status(status_id: int, leave_status: LeaveStatusCreate, db: Session = Depends(get_db)):
    db_leave_status = db.query(LeaveStatus).filter(LeaveStatus.status_id == status_id).first()
    if db_leave_status is None:
        raise HTTPException(status_code=404, detail="LeaveStatus not found")
    db_leave_status.status_name = leave_status.status_name
    db.commit()
    db.refresh(db_leave_status)
    return db_leave_status

@router.delete("/leave-status/{status_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_leave_status(status_id: int, db: Session = Depends(get_db)):
    db_leave_status = db.query(LeaveStatus).filter(LeaveStatus.status_id == status_id).first()
    if db_leave_status is None:
        raise HTTPException(status_code=404, detail="LeaveStatus not found")
    db.delete(db_leave_status)
    db.commit()
    return {"ok": True}