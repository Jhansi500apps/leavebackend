from fastapi import FastAPI, HTTPException, Depends, status,APIRouter
from sqlalchemy.orm import Session
from pydantic import BaseModel
from datetime import date
from typing import List,Optional
from routers.sql import LeaveBalance, engine
from sqlalchemy.orm import sessionmaker
 # Assuming LeaveType is also in the sql module
# app = FastAPI()
router = APIRouter()
# from fastapi.middleware.cors import CORSMiddleware


# Define a list of allowed origins for CORS
# You can use ["*"] to allow all origins
# origins = [
#     "http://localhost:3000",  # Assuming your Vue.js app runs on localhost:3000
#     "http://127.0.0.1:3000",
#     # Add other origins as needed
# ]

# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=origins,  # List of allowed origins
#     allow_credentials=True,
#     allow_methods=["*"],  # Allows all methods
#     allow_headers=["*"],  # Allows all headers
# )
# Dependency
def get_db():
    db = sessionmaker(autocommit=False, autoflush=False, bind=engine)()
    try:
        yield db
    finally:
        db.close()
class LeaveBalanceBase(BaseModel):
    employee_id: int
    leave_type_id: int
    year: int
    total_days: int
    days_taken: int = 0
    remaining_days: Optional[int] = None

class LeaveBalanceCreate(LeaveBalanceBase):
    pass

class LeaveBalanceOut(LeaveBalanceBase):
    balance_id: int

    class Config:
        orm_mode = True
@router.post("/leave-balances/", response_model=LeaveBalanceOut, status_code=status.HTTP_201_CREATED)
def create_leave_balance(leave_balance: LeaveBalanceCreate, db: Session = Depends(get_db)):
    db_leave_balance = LeaveBalance(**leave_balance.dict())
    db.add(db_leave_balance)
    db.commit()
    db.refresh(db_leave_balance)
    return db_leave_balance

@router.get("/leave-balances/", response_model=List[LeaveBalanceOut])
def read_leave_balances(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    leave_balances = db.query(LeaveBalance).offset(skip).limit(limit).all()
    return leave_balances

@router.get("/leave-balances/{balance_id}", response_model=LeaveBalanceOut)
def read_leave_balance(balance_id: int, db: Session = Depends(get_db)):
    leave_balance = db.query(LeaveBalance).filter(LeaveBalance.balance_id == balance_id).first()
    if leave_balance is None:
        raise HTTPException(status_code=404, detail="LeaveBalance not found")
    return leave_balance

@router.put("/leave-balances/{balance_id}", response_model=LeaveBalanceOut)
def update_leave_balance(balance_id: int, leave_balance: LeaveBalanceCreate, db: Session = Depends(get_db)):
    db_leave_balance = db.query(LeaveBalance).filter(LeaveBalance.balance_id == balance_id).first()
    if db_leave_balance is None:
        raise HTTPException(status_code=404, detail="LeaveBalance not found")
    update_data = leave_balance.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_leave_balance, key, value)
    db.commit()
    db.refresh(db_leave_balance)
    return db_leave_balance

@router.delete("/leave-balances/{balance_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_leave_balance(balance_id: int, db: Session = Depends(get_db)):
    db_leave_balance = db.query(LeaveBalance).filter(LeaveBalance.balance_id == balance_id).first()
    if db_leave_balance is None:
        raise HTTPException(status_code=404, detail="LeaveBalance not found")
    db.delete(db_leave_balance)
    db.commit()
    return {"ok": True}