from sqlalchemy import create_engine, Column, Integer, String, Date, DateTime, Text, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

Base = declarative_base()

class Employee(Base):
    __tablename__ = 'Employees'
    employee_id = Column(Integer, primary_key=True, autoincrement=True)
    first_name = Column(String(255), nullable=False)
    last_name = Column(String(255), nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    department = Column(String(255))
    position = Column(String(255))
    join_date = Column(Date, nullable=False)
    status = Column(String(50), default='active')

class LeaveType(Base):
    __tablename__ = 'LeaveTypes'
    leave_type_id = Column(Integer, primary_key=True, autoincrement=True)
    leave_type_name = Column(String(255), nullable=False)
    description = Column(Text)

class LeaveRequest(Base):
    __tablename__ = 'LeaveRequests'
    leave_request_id = Column(Integer, primary_key=True, autoincrement=True)
    employee_id = Column(Integer, ForeignKey('Employees.employee_id'), nullable=False)
    leave_type_id = Column(Integer, ForeignKey('LeaveTypes.leave_type_id'), nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    reason = Column(Text)
    status = Column(String(50), default='pending')
    request_date = Column(DateTime, default=func.now())  # Ensure this line is only here once
    employee = relationship("Employee")
    leave_type = relationship("LeaveType")

class LeaveStatus(Base):
    __tablename__ = 'LeaveStatus'
    status_id = Column(Integer, primary_key=True, autoincrement=True)
    status_name = Column(String(50), nullable=False)

class LeaveBalance(Base):
    __tablename__ = 'LeaveBalance'
    balance_id = Column(Integer, primary_key=True, autoincrement=True)
    employee_id = Column(Integer, ForeignKey('Employees.employee_id'), nullable=False)
    leave_type_id = Column(Integer, ForeignKey('LeaveTypes.leave_type_id'), nullable=False)
    year = Column(Integer, nullable=False)
    total_days = Column(Integer, nullable=False)
    days_taken = Column(Integer, default=0)
    remaining_days = Column(Integer)

# Creating an engine and binding the metadata
engine = create_engine("mysql+pymysql://root:user123@localhost/lms", echo=True)
Base.metadata.create_all(engine)  
