from fastapi import FastAPI, HTTPException, Depends, status,APIRouter
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List
from sqlalchemy.orm import sessionmaker
from routers.sql import  LeaveType, engine 
 # Assuming LeaveType is also in the sql module
# app = FastAPI()
router = APIRouter()
# from fastapi.middleware.cors import CORSMiddleware


# # Define a list of allowed origins for CORS
# # You can use ["*"] to allow all origins
# origins = [
#     "http://localhost:3000",  # Assuming your Vue.js app runs on localhost:3000
#     "http://127.0.0.1:3000",
#     # Add other origins as needed
# ]

# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=origins,  # List of allowed origins
#     allow_credentials=True,
#     allow_methods=["*"],  # Allows all methods
#     allow_headers=["*"],  # Allows all headers
# )
# Dependency
def get_db():
    db = sessionmaker(autocommit=False, autoflush=False, bind=engine)()
    try:
        yield db
    finally:
        db.close()

class LeaveTypeCreate(BaseModel):
    leave_type_name: str
    description: str

class LeaveTypeOut(BaseModel):
    leave_type_id: int
    leave_type_name: str
    description: str

    class Config:
        orm_mode = True
@router.post("/leave-types/", response_model=LeaveTypeOut, status_code=status.HTTP_201_CREATED)
def create_leave_type(leave_type: LeaveTypeCreate, db: Session = Depends(get_db)):
    db_leave_type = LeaveType(**leave_type.dict())
    db.add(db_leave_type)
    db.commit()
    db.refresh(db_leave_type)
    return db_leave_type

@router.get("/leave-types/", response_model=List[LeaveTypeOut])
def read_leave_types(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    leave_types = db.query(LeaveType).offset(skip).limit(limit).all()
    return leave_types

@router.get("/leave-types/{leave_type_id}", response_model=LeaveTypeOut)
def read_leave_type(leave_type_id: int, db: Session = Depends(get_db)):
    leave_type = db.query(LeaveType).filter(LeaveType.leave_type_id == leave_type_id).first()
    if leave_type is None:
        raise HTTPException(status_code=404, detail="LeaveType not found")
    return leave_type

@router.put("/leave-types/{leave_type_id}", response_model=LeaveTypeOut)
def update_leave_type(leave_type_id: int, leave_type: LeaveTypeCreate, db: Session = Depends(get_db)):
    db_leave_type = db.query(LeaveType).filter(LeaveType.leave_type_id == leave_type_id).first()
    if db_leave_type is None:
        raise HTTPException(status_code=404, detail="LeaveType not found")
    for var, value in vars(leave_type).items():
        setattr(db_leave_type, var, value) if value else None
    db.commit()
    db.refresh(db_leave_type)
    return db_leave_type

@router.delete("/leave-types/{leave_type_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_leave_type(leave_type_id: int, db: Session = Depends(get_db)):
    db_leave_type = db.query(LeaveType).filter(LeaveType.leave_type_id == leave_type_id).first()
    if db_leave_type is None:
        raise HTTPException(status_code=404, detail="LeaveType not found")
    db.delete(db_leave_type)
    db.commit()
    return {"ok": True}