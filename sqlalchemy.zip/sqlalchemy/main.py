# from fastapi import FastAPI,Response
# from routers import leavestatus,employee, leavebalance, leaverequest, leavetype  

# app = FastAPI(default_response_class=Response)

# # Assuming each module has a router object named `router`
# app.include_router(router=employee.router)
# app.include_router(leavebalance.router)
# app.include_router(leaverequest.router)
# app.include_router(leavetype.router)
# app.include_router(leavestatus.router)


"""Main app handler"""
import logging
import time
from logging.config import dictConfig
from os import environ


from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi_events.handlers.local import local_handler
from fastapi_events.middleware import EventHandlerASGIMiddleware
from mangum import Mangum
from routers import leavestatus,employee, leavebalance, leaverequest, leavetype  



root_path: str = "/v1"


app = FastAPI(
    root_path=root_path,
    description="leaves",
    title="Leave Mangement System Services",
    contact={
        "name": "500apps",
        "url": "https://500apps.com/contact-us",
        "email": "tech@500apps.com",
    },
    license_info={
        "name": "All rights reserved © 500apps",
        "url": "https://500apps.com",
    },
    swagger_ui_parameters={"persistAuthorization": True},
    redoc_url="/redoc",
)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# registering handler(s)
app.add_middleware(EventHandlerASGIMiddleware, handlers=[local_handler])



@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    """Add process time"""
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response

app.include_router(employee.router)
app.include_router(leavebalance.router)
app.include_router(leaverequest.router)
app.include_router(leavetype.router)
app.include_router(leavestatus.router)

# # Sample route
# app.include_router(prefix="/taskflow", router=task_flow.router, tags=["Taskflow"])


# app.include_router(prefix="/taskflow", router=invoke_job.router, tags=["Taskflow"])


# app.include_router(router=stop_flow.router, tags=["Taskflow"])



@app.exception_handler(Exception)
async def unicorn_exception_handler(request: Request, exc: Exception):
    """Expection handler"""
    logger.info(request)
    return JSONResponse(
        status_code=400,
        content={"message": "Oops! There goes a rainbow...", "code": str(exc)},
    )



# for lambda handler
handler = Mangum(app=app, api_gateway_base_path=root_path)